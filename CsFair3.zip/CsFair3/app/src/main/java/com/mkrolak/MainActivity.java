package com.mkrolak;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends FragmentActivity {
    private int[] LAYOUT_ARRAY;

    private int maxSlide = 3;

    FirebaseAuth mAuth;

    public ViewPager mPager;
    public PagerAdapter mPagerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        FirebaseAuth.getInstance();
        setContentView(R.layout.activity_main);
        LAYOUT_ARRAY = new int[] {R.layout.fragment_username,R.layout.fragment_password,R.layout.fragment_new_user,R.layout.fragment_verify};


        mPager = (ViewPager) findViewById(R.id.pager);
        mPagerAdapter = new ScreenSlidePagerAdapter(getSupportFragmentManager());
        mPager.setAdapter(mPagerAdapter);


    }

    @Override
    protected void onStart() {
        super.onStart();
         mAuth = FirebaseAuth.getInstance();


    }

    @Override
    public void onBackPressed(){
        if(mPager.getCurrentItem() != 0){
            mPager.setCurrentItem(mPager.getCurrentItem()-1);

        }else{
            super.onBackPressed();
        }
    }

    public void continueToNext(View v){
        if(mPager.getCurrentItem()+1 != maxSlide){
            mPager.setCurrentItem(mPager.getCurrentItem()+1);


        }

    }


    //TODO:Make more clear on where stuff went wrong.
    public void continueSignUp(View v){
        maxSlide = 4;
        String email = (((LoginFragment)((ScreenSlidePagerAdapter)mPagerAdapter).getItem(0)).getInfo())+"@cps.edu";
        String password = (((LoginFragment)((ScreenSlidePagerAdapter)mPagerAdapter).getItem(1)).getInfo());
        ((TextView)((ScreenSlidePagerAdapter)mPagerAdapter).getItem(3).getView().findViewById(R.id.verifyName)).setText("Please confirm the verification email that was sent to "+email);


        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    continueToNext(null);
                    verifyEmail();


                }
            }
        });

    }

    public void verifyEmail(){
        mAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    startActivity(new Intent(MainActivity.this,HomeActivity.class));
                }

            }
        });
    }

    public  void login(View v){

        String email = (((LoginFragment)((ScreenSlidePagerAdapter)mPagerAdapter).getItem(0)).getInfo())+"@cps.edu";
        String password = (((LoginFragment)((ScreenSlidePagerAdapter)mPagerAdapter).getItem(1)).getInfo());

        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    if(mAuth.getCurrentUser().isEmailVerified()){
                        startActivity(new Intent(MainActivity.this,HomeActivity.class));
                    }else{
                        continueToNext(null);
                        verifyEmail();
                    }

                }else{
                    ((LoginFragment)((ScreenSlidePagerAdapter)(mPagerAdapter)).getItem(2)).setErrorText(task.getException().toString());
                }
            }
        });
    }





    private class ScreenSlidePagerAdapter extends FragmentStatePagerAdapter {

        public Fragment[] fragmentList;
        public ScreenSlidePagerAdapter(FragmentManager fm) {
            super(fm);
            fragmentList = new Fragment[LAYOUT_ARRAY.length];
            for(int i =0; i < fragmentList.length;i++){
                fragmentList[i] = new LoginFragment(LAYOUT_ARRAY[i]);
            }
        }

        @Override
        public Fragment getItem(int position) {

            return fragmentList[position];
        }

        @Override
        public int getCount() {
            return LAYOUT_ARRAY.length;
        }


    }
}
