package com.mkrolak;


import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.UserProfileChangeRequest;


public class SignUpActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_sign_up);
        getSupportActionBar().hide();


    }

    public void createAccount(View view){
        String email = ((TextView)(findViewById(R.id.email))).getText().toString();
        String password = ((TextView)(findViewById(R.id.info))).getText().toString();
        String name = ((TextView)findViewById(R.id.info)).getText().toString();
        if(!email.isEmpty() && !password.isEmpty() && !name.isEmpty()) {
            mAuth.createUserWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Intent intent = new Intent(SignUpActivity.this, HomeActivity.class);
                                String name = ((TextView) findViewById(R.id.info)).getText().toString();
                                UserProfileChangeRequest userProfileChangeRequest = new UserProfileChangeRequest.Builder().setDisplayName(name).build();
                                mAuth.getCurrentUser().updateProfile(userProfileChangeRequest);
                                startActivity(intent);
                            } else {
                                ((TextView) (findViewById(R.id.failText))).setText(task.getException().toString());
                            }

                        }
                    });
        }else{
            ((TextView) (findViewById(R.id.failText))).setText("All Fields Must Be Completed");
        }
    }
}
